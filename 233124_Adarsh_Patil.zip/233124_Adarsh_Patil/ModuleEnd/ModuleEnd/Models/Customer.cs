﻿using System.ComponentModel.DataAnnotations;

namespace ModuleEnd.Models
{
    public class Customer
    {
        [Key] public int Id { get; set; }
        public string Name { get; set; }
        [EmailAddress(ErrorMessage ="enter correct email")]
        public string EmailId { get; set; }
       
         public int MobileNo { get; set; }
        public string Address { get; set; }
         public string City { get; set; } 
    }
}
