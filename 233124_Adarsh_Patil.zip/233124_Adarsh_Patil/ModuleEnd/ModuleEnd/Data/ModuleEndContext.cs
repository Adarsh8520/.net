﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ModuleEnd.Models;

namespace ModuleEnd.Data
{
    public class ModuleEndContext : DbContext
    {
        public ModuleEndContext (DbContextOptions<ModuleEndContext> options)
            : base(options)
        {
        }

        public DbSet<ModuleEnd.Models.Customer> Customer { get; set; } = default!;
    }
}
